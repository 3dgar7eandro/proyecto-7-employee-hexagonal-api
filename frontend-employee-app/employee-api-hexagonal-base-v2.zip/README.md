# Employee API

Proyecto API REST con arquitectura hexagonal, Spring Boot, PostgreSQL, Docker, JWT, CI/CD.
